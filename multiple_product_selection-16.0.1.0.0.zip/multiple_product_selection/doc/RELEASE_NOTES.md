## Module <multiple_product_selection>

#### 12.07.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Multiple Product Selection